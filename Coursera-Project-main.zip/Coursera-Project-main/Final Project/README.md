## The Unix Workbench Course Peer-Graded Assignment
*by Johns Hopkins University on [coursera.org](https://www.coursera.org/).*
\
**Description**: make a program called *guessinggame.sh*. This program should continuously ask the user to guess the number of files in the current directory, until they guess the correct number. The user is informed if their guess is too high or too low. Once the user guesses the correct number of files in the current directory they should be congratulated.
\
**Make date**: Mon Aug 10 13:26:23 IST 2020
\
**Number of lines in guessinggame.sh:** 24

**KUDOS!!!**

**Warm Regards,**
\
**Piyush Sambhi**
